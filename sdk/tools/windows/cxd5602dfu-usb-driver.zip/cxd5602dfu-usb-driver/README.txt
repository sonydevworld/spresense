
CXD5602 DFU Device Installation Instruction

Copyright 2015 Sony Corporation 
Driver Ver. 05/11/2015,1.0.0.0


Description
===========
This document describes how to install CXD5602 DFU device driver to the target
Windows system.


Supported operating system
==========================
Windows 7   32/64-bit 
Windows 8   32/64-bit 
Windows 8.1 32/64-bit 
Windows 10  32/64-bit 


Installation manual
===================
Method 1:
---------
1. Select the "Install" menu item after right-clicking on the "cxd5602dfu.inf"
2. Power On CXD5602 Target Board with BOOTREC enabled.
3. Open Device Manager
     Press Win + E shortcut keys on the keyboard.
   ->In Windows 7 / Windows 8, it will open "Computer" for you. 
     Right-click "Computer" and select Properties->Device Manager.
   ->In Windows 8.1, it will open "This PC" for you. 
     Right-click "This PC" and select Properties->Device Manager.
4. Confirm "CXD5602" being shown in Device Manager, if "Unknown Device" shown,
   then execute step 5
5. Right-click "Unknown Device", and Choose "Scan for hardware changes"

Method 2:
---------
1. Power On CXD5602 Target Board with BOOTREC enabled.
2. Open Device Manager
     Press Win + E shortcut keys on the keyboard.
   ->In Windows 7 / Windows 8, it will open "Computer" for you.
     Right-click "Computer" and select Properties->Device Manager.
   ->In Windows 8.1, it will open "This PC" for you. 
     Right-click "This PC" and select Properties->Device Manager.
3. "Unknown Device" is shown in Device Manager
4. Right-click "Unknown Device", and Choose "Update Driver Software"
5. Next, choose "Browse my computer for driver software"
6. Click "Browse", specify the path where you put "cxd5602dfu.inf",
   then click "Next".
7. After installation is complete, "CXD5602" will be shown in Device Manager
