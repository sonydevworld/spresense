
CXD5602 CDC Device Installation Instruction

Copyright 2015 Sony Corporation 
Driver Ver. 10/11/2016,1.0.1.0


Description
===========
CXD5602 CDC device is developped,to support CXD5602 running on Windows OS.


Disclaimer
===========
Copyright 2015 Sony Corporation 

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
1. Redistributions of source code must retain the above copyright notice, this
list of conditions, and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation 
and/or other materials provided with the distribution

THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS
OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,THE IMPLIED WARRANTIES OF 
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.IN NO EVENT
SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR 
BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING 
IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF 
SUCH DAMAGE.


OS Environment
==============
Supported: 
Windows 7   32/64-bit 
Windows 8   32/64-bit 
Windows 8.1 32/64-bit 

Installation manual
===================
Method 1:
---------
1. Select the "Install" menu item after right-clicking on the "cxd5602cdc.inf"
2. Power On CXD5602 Target Board
3. Open Device Manager
     Press Win + E shortcut keys on the keyboard.
   ->In Windows 7 / Windows 8, it will open "Computer" for you. 
     Right-click "Computer" and select Properties->Device Manager.
   ->In Windows 8.1, it will open "This PC" for you. 
     Right-click "This PC" and select Properties->Device Manager.
4. Confirm "CXD5602 CDC Port" being shown in Device Manager, if "Unknown Device" shown,
   then execute step 5   
5. Right-click "Unknown Device", and Choose "Scan for hardware changes"

Method 2:
---------
1. Power On CXD5602 Target Board
2. Open Device Manager
     Press Win + E shortcut keys on the keyboard.
   ->In Windows 7 / Windows 8, it will open "Computer" for you. 
     Right-click "Computer" and select Properties->Device Manager.
   ->In Windows 8.1, it will open "This PC" for you. 
     Right-click "This PC" and select Properties->Device Manager.
3. "Unknown Device" is shown in Device Manager
4. Right-click "Unknown Device",and Choose "Update Driver Software"
5. Next, choose "Browse my computer for driver software"
6. Click "Browse",Specify the path where you put "cxd5602cdc.inf",then click "Next"
7. After installation is complete, "CXD5602 CDC Port"COM will be shown in Device Manager